package feedback;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class TC_feedback_17 {

 WebDriver cDriver;
 TC_feedback_17 ()
    {
    WebDriverManager.chromedriver().setup();
    cDriver=new ChromeDriver();
    }
   
void give_Feedback() throws InterruptedException {

cDriver.get("https://www.amazon.in/");
cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("socs");
Thread.sleep(2000);
cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
Thread.sleep(2000);
cDriver.findElement(By.xpath("//div[3]//div[1]//span[1]//div[1]//div[1]//div[1]//div[1]//div[2]//div[1]//span[1]//a[1]//div[1]")).click();
Thread.sleep(2000);
Set<String> ids = cDriver.getWindowHandles();
Iterator<String> it = ids.iterator();
String parentId = it.next();
String childId = it.next();
cDriver.switchTo().window(childId);
cDriver.findElement(By.xpath("//div[@id='averageCustomerReviews']//span[@id='acrCustomerReviewText']")).click();
cDriver.findElement(By.xpath("//*[@id=\"histogramTable\"]/tbody/tr[1]/td[2]/a/div")).click();
	cDriver.findElement(By.id("a-autoid-9-announce")).click();
	WebElement emailidElement1=cDriver.findElement(By.xpath("//input[@id='ap_email']"));
	emailidElement1.sendKeys("suryarajan361@gmail.com");

	cDriver.findElement(By.xpath("//input[@id='continue']")).click();
	WebElement passwordElement2= cDriver.findElement(By.xpath("//input[@id='ap_password']"));
	passwordElement2.sendKeys("Feb151998@");
	cDriver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
	System.out.println("Test case passed");
    WebElement txt=cDriver.findElement(By.xpath("//*[@id=\"customer_review-RPMEUX59S54KS\"]/div[7]/div/div[1]/div/div"));
    String s=txt.getText();
    System.out.println(s);
    
}


public static void main(String[] args) {
try
{
TC_feedback_17 tc=new  TC_feedback_17();
   tc.give_Feedback();
 
}
catch(Exception e)
{

}

}
}