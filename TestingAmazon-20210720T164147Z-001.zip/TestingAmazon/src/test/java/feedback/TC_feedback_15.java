package feedback;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class TC_feedback_15 {

 WebDriver cDriver;
 TC_feedback_15 ()
    {
    WebDriverManager.chromedriver().setup();
    cDriver=new ChromeDriver();
    }
   
void check_StarRatings() throws InterruptedException {

cDriver.get("https://www.amazon.in/");
cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("headset");
cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
cDriver.findElement(By.xpath("//img[@alt='Sponsored Ad - pTron Studio Over-Ear Bluetooth 5.0 Wireless Headphones, Hi-Fi Sound with Deep Bass, 12Hrs Playback, Ergono...']")).click();
Set<String> ids = cDriver.getWindowHandles();
Iterator<String> it = ids.iterator();
String parentId = it.next();
String childId = it.next();
cDriver.switchTo().window(childId);
cDriver.findElement(By.xpath("//div[@id='averageCustomerReviews_feature_div']//span[@id='acrCustomerReviewText']")).click();
System.out.println("Test Case Passed");

}

public static void main(String[] args) {
try
{
TC_feedback_15 tc=new  TC_feedback_15 ();
   tc.check_StarRatings();
 
}
catch(Exception e)
{

}

}
}

