package Searching;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class TC_search_08 {
	
	  WebDriver cDriver;
	  TC_search_08 ()
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 cDriver=new ChromeDriver();
	     }
	     
	 void checkSearch_product() throws InterruptedException {
		 cDriver.get("https://www.amazon.in/");
		 cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("ladies watches");
		 cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
		 System.out.println("Searched Item Succesfully");
		 
	 }

	public static void main(String[] args) {
		try
		{
			 TC_search_08 tc=new  TC_search_08();	
		    tc.checkSearch_product();
		  
		 }
		catch(Exception e)
		{

	}

}
}

