package browserCompactability;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class TC_browser_18 {
	 WebDriver cDriver;
	 TC_browser_18 ()
	    {
	    WebDriverManager.chromedriver().setup();
	    cDriver=new ChromeDriver();
	    }
	   
	public void check_Browsercomp() { 
		cDriver.get("https://www.amazon.in/");
		WebElement logo=cDriver.findElement(By.xpath("//a[@id='nav-logo-sprites']"));
			System.out.println(logo.isDisplayed());
		WebElement Indian_flag=cDriver.findElement(By.xpath("//span[@class='icp-nav-flag icp-nav-flag-in']"));
		    System.out.println(Indian_flag.isDisplayed());
		WebElement Sign_In=cDriver.findElement(By.xpath("//a[@id='nav-link-accountList']"));
		    System.out.println(Sign_In.isDisplayed());
		WebElement Search_textbox=cDriver.findElement(By.id("twotabsearchtextbox"));
		     System.out.println(Search_textbox.isEnabled());
		WebElement return_order=cDriver.findElement(By.xpath("//a[@id='nav-orders']"));
		     System.out.println(return_order.isEnabled());  
		WebElement location=cDriver.findElement(By.id("nav-global-location-popover-link"));
		     System.out.println(location.isDisplayed()); 
		WebElement cart=cDriver.findElement(By.xpath("//a[@id='nav-cart']"));
		      System.out.println(cart.isEnabled());
		    
		
		     
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		TC_browser_18 tc=new  TC_browser_18 ();
		   tc.check_Browsercomp();
		 
		}
		catch(Exception e)
		{

		}
	}

}
