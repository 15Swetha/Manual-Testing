package registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_newuser_02 {
     WebDriver cDriver;
     TC_newuser_02()
     {
    	 WebDriverManager.chromedriver().setup();
    	 cDriver=new ChromeDriver();
     }
     
     
	 void valid_Newuser() throws InterruptedException
	 {
		    cDriver.get("https://www.amazon.in/");
			
			cDriver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span")).click();
		    Thread.sleep(2000);
		   
			cDriver.findElement(By.id("createAccountSubmit")).click();
			Thread.sleep(2000);
		    WebElement nameElement=cDriver.findElement(By.id("ap_customer_name"));
			nameElement.sendKeys("Aji");
		    Thread.sleep(2000);	
			WebElement emailidElement=cDriver.findElement(By.id("ap_email"));
			emailidElement.sendKeys("suryarajan361@gmail.com");
			Thread.sleep(2000);	
		    WebElement phoneElement=cDriver.findElement(By.xpath("//input[@id='ap_phone_number']"));
			phoneElement.sendKeys("9566572539");
			Thread.sleep(2000);	
			WebElement passwordElement= cDriver.findElement(By.xpath("//input[@id='ap_password']"));

			passwordElement.sendKeys("Feb151998@");
			Thread.sleep(2000);	
			    
			cDriver.findElement(By.id("continue")).click();
			System.out.println("Test Case Passed");
			System.out.println("Already having account with this EmailId");
	 }
	
	 
	public static void main(String[] args) {
		try
		{
			TC_newuser_02 tc=new TC_newuser_02();	
		    tc.valid_Newuser();
		  
		 }
		catch(Exception e)
		{
			
		}

	}

}

