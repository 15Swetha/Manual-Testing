package addtocart;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class TC_cart_11 {
	
	  WebDriver cDriver;
	  TC_cart_11()
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 cDriver=new ChromeDriver();
	     }
	     
	 void check_delete() throws InterruptedException {
		 cDriver.get("https://www.amazon.in/");
		 cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("ladies watches");
		 cDriver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
		 cDriver.findElement(By.xpath("//img[@alt=\"Sponsored Ad - Giordano Analog Women's Watch - A2057\"]")).click();
		 Set<String> ids = cDriver.getWindowHandles();
		 Iterator<String> it = ids.iterator();
		 String parentId = it.next();
		 String childId = it.next();
		 cDriver.switchTo().window(childId);
		 cDriver.findElement(By.id("add-to-cart-button")).click();
		 cDriver.findElement(By.id("nav-cart")).click();
		 cDriver.findElement(By.cssSelector(" input[value='Delete']")).click();
		 System.out.println("Test cases passed");
		 System.out.println("product is deleted successfully");
		
	 }

	public static void main(String[] args) {
		try
		{
			TC_cart_11 tc=new  TC_cart_11 ();	
		    tc.check_delete();
		  
		 }
		catch(Exception e)
		{

	}

}
}

