package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_existinguser_04 {

	  WebDriver cDriver;
	     TC_existinguser_04()
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 cDriver=new ChromeDriver();
	     }
	     
	     void invalid_Username() throws InterruptedException
	     {
	    		 cDriver.get("https://www.amazon.in/");
	    		 cDriver.findElement(By.xpath("//*[@id=\"nav-link-accountList\"]/span")).click();
	    		 WebElement emailidElement1=cDriver.findElement(By.xpath("//input[@id='ap_email']"));
	    		 emailidElement1.sendKeys("suryarajan36@gmail.com");
	         	 cDriver.findElement(By.xpath("//input[@id='continue']")).click();
	         	System.out.println("Test case failed");
	         	System.out.println("Invalid EmailAddress");

	            WebElement txt=cDriver.findElement(By.xpath("//*[@id=\"auth-error-message-box\"]/div/div/ul/li/span"));
	            String s=txt.getText();
	            System.out.println(s);
	            
	    		 WebElement passwordElement2= cDriver.findElement(By.xpath("//input[@id='ap_password']"));
	             passwordElement2.sendKeys("Feb151998@");
	    		 cDriver.findElement(By.xpath("//input[@id='signInSubmit']")).click();
	    					    
	    		 Thread.sleep(2000);
	    		 cDriver.close();	    	
	    	 
	     }
     
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			TC_existinguser_04 tc=new TC_existinguser_04();	
		    tc.invalid_Username();
		  
		 }
		catch(Exception e)
		{
			

	}

	}
}