package productpage;
import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_product_06
{
	
	  WebDriver cDriver;
	  TC_product_06()
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 cDriver=new ChromeDriver();
	     }
	     
	 void checkProduct_features() throws InterruptedException
	 {
		 cDriver.get("https://www.amazon.in/");
		 cDriver.findElement(By.xpath("//*[@id=\"nav-hamburger-menu\"]")).click();
		  // Click on Mobile, Computer menu
		 Thread.sleep(2000);
		  cDriver.findElement(By.cssSelector(".hmenu-item[data-menu-id='8']")).click();
		  Thread.sleep(2000);
		  // Click on Tablets
		  cDriver.findElement(By.xpath("//a[@class='hmenu-item'][normalize-space()='Tablets']")).click();
		  Thread.sleep(2000);
		  cDriver.findElement(By.xpath("//div[@class='a-row apb-browse-two-col-center-pad']//div[2]//div[1]//div[1]//div[2]//div[1]//a[1]//h2[1]")).click();
		  WebElement txt=cDriver.findElement(By.xpath("//*[@id=\"feature-bullets\"]"));
		  String s=txt.getText();
		  System.out.println(s);
		  WebElement productdetails =cDriver.findElement(By.xpath("//*[@id=\"productDetails_feature_div\"]"));
		  productdetails.click();
		  Boolean b_productimage= productdetails.isDisplayed();
 	      if(b_productimage)
 		  {
 	 		
 	 		System.out.println("Product description page is viewed successfull.");
 	 		System.out.println("Test cases passed");
 	 		
 		  }
 		 else 
 		  {
 			System.out.println("test is failed");	
 		  }
	 }

	public static void main(String[] args) {
		try
		{
			TC_product_06 tc=new  TC_product_06();	
		    tc.checkProduct_features();
		  
		 }
		catch(Exception e)
		{

	}
}
}

