package productpage;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_product_05 
{
	
	  WebDriver cDriver;
	  TC_product_05()
	     {
	    	 WebDriverManager.chromedriver().setup();
	    	 cDriver=new ChromeDriver();
	     }
	     
	 void checkProduct() throws InterruptedException {
		 cDriver.get("https://www.amazon.in/");
		 WebElement productElement=cDriver.findElement(By.xpath("//div[@class='a-section a-spacing-none aok-relative']"));
		 Boolean b_productElement= productElement.isDisplayed();
 	     if(b_productElement)
 		  {
 	 		System.out.println("Test cases passed");
 	 		System.out.println("Product page is visible");
 		  }
 		 else 
 		  {
 			System.out.println("test is failed");	
 		  }
		
	 }

	public static void main(String[] args) {
		try
		{
			TC_product_05 tc=new  TC_product_05 ();	
		    tc.checkProduct();
		  
		 }
		catch(Exception e)
		{

	}
}
}
